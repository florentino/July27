﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.NTC_Model
{
    public class FilePathMaintenance
    {
        private int _PathID;

        public int PathID
        {
            get { return _PathID; }
            set { _PathID = value; }
        }

        private string _ICBSFilePath;

        [Required(ErrorMessage = "ICBS Path is required.")]
        public string ICBSFilePath
        {
            get { return _ICBSFilePath; }
            set
            {
                Validator.ValidateProperty(value, new ValidationContext(this, null, null) { MemberName = "ICBSFilePath" });
                _ICBSFilePath = value;
            }
        }

        private string _ICBSTextKeyword;

        public string ICBSTextKeyword
        {
            get { return _ICBSTextKeyword; }
            set { _ICBSTextKeyword = value; }
        }

        private string _ICBSFileExtension;

        public string ICBSFileExtension
        {
            get { return _ICBSFileExtension; }
            set { _ICBSFileExtension = value; }
        }


        private string _AAFFilePath;

        [Required(ErrorMessage = "AAF Path is required.")]
        public string AAFFilePath
        {
            get { return _AAFFilePath; }
            set
            {
                Validator.ValidateProperty(value, new ValidationContext(this, null, null) { MemberName = "AAFFilePath" });
                _AAFFilePath = value;
            }
        }

        private string _AAFTextKeyword;

        public string AAFTextKeyword
        {
            get { return _AAFTextKeyword; }
            set { _AAFTextKeyword = value; }
        }

        private string _AAFFileExtension;

        public string AAFFileExtension
        {
            get { return _AAFFileExtension; }
            set { _AAFFileExtension = value; }
        }

        private string _FAMSFilePath;

        [Required(ErrorMessage = "FaMS Path is required.")]
        public string FAMSFilePath
        {
            get { return _FAMSFilePath; }
            set
            {
                Validator.ValidateProperty(value, new ValidationContext(this, null, null) { MemberName = "FAMSFilePath" });
                _FAMSFilePath = value;
            }
        }

        private string _FAMSTextKeyword;

        public string FAMSTextKeyword
        {
            get { return _FAMSTextKeyword; }
            set { _FAMSTextKeyword = value; }
        }

        private string _FAMSFileExtension;

        public string FAMSFileExtension
        {
            get { return _FAMSFileExtension; }
            set { _FAMSFileExtension = value; }
        }

        private string _UserName;

        public string UserName
        {
            get { return _UserName; }
            set { _UserName = value; }
        }

        private DateTime _DateInserted;

        public DateTime DateInserted
        {
            get { return _DateInserted; }
            set { _DateInserted = value; }
        }
        
    }
}
