﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.NTC_Model
{
    public class AAFModel
    {
        private string _SYSTEM;
        private string _AccountNo;
        private string _ClientName;
        private string _AO;
        private string _FacilityCode;
        private string _StatusPERSYSTEM;
        private string _ValueDate;
        private string _FirstDueDate;
        private string _MaturityDate;
        private string _TotalLoan;
        private string _OB;
        private string _MonthlyOB;
        private string _UDIBalance;
        private string _OrigERV;
        private string _PVRV;
        private string _OrigGD;
        private string _PVGD;
        private string _OriginalRate;
        private string _CurrentRate;
        private string _TermInmonths;
        private string _RemainingTermInMonths;
        private string _OriginalAmortizationAAF;
        private string _PaymentScheduleAmortizationAAF;
        private string _RepricedDate;
        private string _AAFICBSRateType;
        private string _RepricedAmortization;
        private string _PastDueDateITLDateExtractedPerAAFICBS;
        private string _PerFaMSAAFICBSIndustryCode;
        private string _IndustryHeader;
        private string _IndustryDetail;
        private string _Collateral;
        private string _PerFaMSAAFICBSAssetSizeInwords;
        private string _ICBSGLCODE;
        private string _ICBSGLName;
        private string _COSTCENTER;
        private string _BRANCHNAMEOFCOSTCENTERPERSYSTEM;
        private string _OriginatingBranchBooked;
        private string _NationalityPerICBS;
        private string _NextRateReviewDateExtractedPerFaMSAAFICBS;
        private string _TAXID;
        private string _CustomerTypeDescription;
        private string _RELCode;
        private string _REECode;
        private string _REEAddtlInfo;
        private string _AcctRef;
        private string _RPT;
        private string _ASSETCOST;
        private string _LeaseType;
        private string _ICBSCollateralCode;
        private string _AssetValue;
        private string _ApprovedAmount;
        private string _LastPrincipalPay;
        private string _PrincipalPayDate;
        private string _LastInterestPay;
        private string _LastInterestPayDate;
        private string _PreviousMonthsNPLTaggingByRisk;
        private string _SpecificRequiredProvisions;
        private string _GeneralRequiredProvisions;
        private string _ClientsEquity;
        private string _AccruedInterestReceivable;
        private string _RecordDate;
        private string _Reason;
        private int _TranNo;
        private string _RawFiles;
        private bool _isDeleted;
        private string _UserName;
        private DateTime _TransDate;
        private bool _isConsolidated;

        public bool isConsolidated
        {
            get { return _isConsolidated; }
            set { _isConsolidated = value; }
        }

        public DateTime TransDate
        {
            get { return _TransDate; }
            set { _TransDate = value; }
        }

        public string UserName
        {
            get { return _UserName; }
            set { _UserName = value; }
        }

        public bool isDeleted
        {
            get { return _isDeleted; }
            set { _isDeleted = value; }
        }

        public string RawFiles
        {
            get { return _RawFiles; }
            set { _RawFiles = value; }
        }

        public int TranNo
        {
            get { return _TranNo; }
            set { _TranNo = value; }
        }

        public string Reason
        {
            get { return _Reason; }
            set { _Reason = value; }
        }

        public string RecordDate
        {
            get { return _RecordDate; }
            set { _RecordDate = value; }
        }

        public string SYSTEM
        {
            get { return _SYSTEM; }
            set { _SYSTEM = value; }
        }

        public string AccountNo
        {
            get { return _AccountNo; }
            set { _AccountNo = value; }
        }

        public string ClientName
        {
            get { return _ClientName; }
            set { _ClientName = value; }
        }
        public string AO
        {
            get { return _AO; }
            set { _AO = value; }
        }

        public string FacilityCode
        {
            get { return _FacilityCode; }
            set { _FacilityCode = value; }
        }

        public string StatusPERSYSTEM
        {
            get { return _StatusPERSYSTEM; }
            set { _StatusPERSYSTEM = value; }
        }

        public string ValueDate
        {
            get { return _ValueDate; }
            set { _ValueDate = value; }
        }

        public string FirstDueDate
        {
            get { return _FirstDueDate; }
            set { _FirstDueDate = value; }
        }

        public string MaturityDate
        {
            get { return _MaturityDate; }
            set { _MaturityDate = value; }
        }

        public string TotalLoan
        {
            get { return _TotalLoan; }
            set { _TotalLoan = value; }
        }

        public string OB
        {
            get { return _OB; }
            set { _OB = value; }
        }

        public string MonthlyOB
        {
            get { return _MonthlyOB; }
            set { _MonthlyOB = value; }
        }

        public string UDIBalance
        {
            get { return _UDIBalance; }
            set { _UDIBalance = value; }
        }

        public string OrigERV
        {
            get { return _OrigERV; }
            set { _OrigERV = value; }
        }

        public string PVRV
        {
            get { return _PVRV; }
            set { _PVRV = value; }
        }

        public string OrigGD
        {
            get { return _OrigGD; }
            set { _OrigGD = value; }
        }

        public string PVGD
        {
            get { return _PVGD; }
            set { _PVGD = value; }
        }

        public string OriginalRate
        {
            get { return _OriginalRate; }
            set { _OriginalRate = value; }
        }

        public string CurrentRate
        {
            get { return _CurrentRate; }
            set { _CurrentRate = value; }
        }

        public string TermInmonths
        {
            get { return _TermInmonths; }
            set { _TermInmonths = value; }
        }

        public string RemainingTermInMonths
        {
            get { return _RemainingTermInMonths; }
            set { _RemainingTermInMonths = value; }
        }

        public string OriginalAmortizationAAF
        {
            get { return _OriginalAmortizationAAF; }
            set { _OriginalAmortizationAAF = value; }
        }
        
        public string PaymentScheduleAmortizationAAF
        {
            get { return _PaymentScheduleAmortizationAAF; }
            set { _PaymentScheduleAmortizationAAF = value; }
        }

        public string RepricedDate
        {
            get { return _RepricedDate; }
            set { _RepricedDate = value; }
        }

        public string AAFICBSRateType
        {
            get { return _AAFICBSRateType; }
            set { _AAFICBSRateType = value; }
        }

        public string RepricedAmortization
        {
            get { return _RepricedAmortization; }
            set { _RepricedAmortization = value; }
        }

        public string PastDueDateITLDateExtractedPerAAFICBS
        {
            get { return _PastDueDateITLDateExtractedPerAAFICBS; }
            set { _PastDueDateITLDateExtractedPerAAFICBS = value; }
        }

        public string PerFaMSAAFICBSIndustryCode
        {
            get { return _PerFaMSAAFICBSIndustryCode; }
            set { _PerFaMSAAFICBSIndustryCode = value; }
        }

        public string IndustryHeader
        {
            get { return _IndustryHeader; }
            set { _IndustryHeader = value; }
        }

        public string IndustryDetail
        {
            get { return _IndustryDetail; }
            set { _IndustryDetail = value; }
        }

        public string Collateral
        {
            get { return _Collateral; }
            set { _Collateral = value; }
        }

        public string PerFaMSAAFICBSAssetSizeInwords
        {
            get { return _PerFaMSAAFICBSAssetSizeInwords; }
            set { _PerFaMSAAFICBSAssetSizeInwords = value; }
        }

        public string ICBSGLCODE
        {
            get { return _ICBSGLCODE; }
            set { _ICBSGLCODE = value; }
        }

        public string ICBSGLName
        {
            get { return _ICBSGLName; }
            set { _ICBSGLName = value; }
        }

        public string COSTCENTER
        {
            get { return _COSTCENTER; }
            set { _COSTCENTER = value; }
        }

        public string BRANCHNAMEOFCOSTCENTERPERSYSTEM
        {
            get { return _BRANCHNAMEOFCOSTCENTERPERSYSTEM; }
            set { _BRANCHNAMEOFCOSTCENTERPERSYSTEM = value; }
        }

        public string OriginatingBranchBooked
        {
            get { return _OriginatingBranchBooked; }
            set { _OriginatingBranchBooked = value; }
        }

        public string NationalityPerICBS
        {
            get { return _NationalityPerICBS; }
            set { _NationalityPerICBS = value; }
        }

        public string NextRateReviewDateExtractedPerFaMSAAFICBS
        {
            get { return _NextRateReviewDateExtractedPerFaMSAAFICBS; }
            set { _NextRateReviewDateExtractedPerFaMSAAFICBS = value; }
        }

        public string TAXID
        {
            get { return _TAXID; }
            set { _TAXID = value; }
        }

        public string CustomerTypeDescription
        {
            get { return _CustomerTypeDescription; }
            set { _CustomerTypeDescription = value; }
        }

        public string RELCode
        {
            get { return _RELCode; }
            set { _RELCode = value; }
        }

        public string REECode
        {
            get { return _REECode; }
            set { _REECode = value; }
        }

        public string REEAddtlInfo
        {
            get { return _REEAddtlInfo; }
            set { _REEAddtlInfo = value; }
        }

        public string AcctRef
        {
            get { return _AcctRef; }
            set { _AcctRef = value; }
        }

        public string RPT
        {
            get { return _RPT; }
            set { _RPT = value; }
        }

        public string ASSETCOST
        {
            get { return _ASSETCOST; }
            set { _ASSETCOST = value; }
        }

        public string LeaseType
        {
            get { return _LeaseType; }
            set { _LeaseType = value; }
        }

        public string ICBSCollateralCode
        {
            get { return _ICBSCollateralCode; }
            set { _ICBSCollateralCode = value; }
        }

        public string AssetValue
        {
            get { return _AssetValue; }
            set { _AssetValue = value; }
        }

        public string ApprovedAmount
        {
            get { return _ApprovedAmount; }
            set { _ApprovedAmount = value; }
        }
        public string LastPrincipalPay
        {
            get { return _LastPrincipalPay; }
            set { _LastPrincipalPay = value; }
        }
        public string PrincipalPayDate
        {
            get { return _PrincipalPayDate; }
            set { _PrincipalPayDate = value; }
        }
        public string LastInterestPay
        {
            get { return _LastInterestPay; }
            set { _LastInterestPay = value; }
        }
        public string LastInterestPayDate
        {
            get { return _LastInterestPayDate; }
            set { _LastInterestPayDate = value; }
        }

        public string ClientsEquity
        {
            get { return _ClientsEquity; }
            set { _ClientsEquity = value; }
        }

        

        public string AccruedInterestReceivable
        {
            get { return _AccruedInterestReceivable; }
            set { _AccruedInterestReceivable = value; }
        }


        public string PreviousMonthsNPLTaggingByRisk
        {
            get { return _PreviousMonthsNPLTaggingByRisk; }
            set { _PreviousMonthsNPLTaggingByRisk = value; }
        }
        public string SpecificRequiredProvisions
        {
            get { return _SpecificRequiredProvisions; }
            set { _SpecificRequiredProvisions = value; }
        }
        public string GeneralRequiredProvisions
        {
            get { return _GeneralRequiredProvisions; }
            set { _GeneralRequiredProvisions = value; }
        }
       
    }
}
