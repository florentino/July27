﻿namespace NTC_Consolidator.NTC_View
{
    partial class frmCorrespondingGL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblErrGLName = new MetroFramework.Controls.MetroLabel();
            this.lblErrGLCode = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.txtGLCode = new MetroFramework.Controls.MetroTextBox();
            this.btnSubmit = new MetroFramework.Controls.MetroButton();
            this.txtGLName = new MetroFramework.Controls.MetroTextBox();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.metroGridGL = new MetroFramework.Controls.MetroGrid();
            this.btnSearch = new MetroFramework.Controls.MetroButton();
            this.txtSearch = new MetroFramework.Controls.MetroTextBox();
            this.txtProductDesc = new MetroFramework.Controls.MetroTextBox();
            this.lblErrProductDesc = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.lblErrSystemTagging = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.cmbSysTagging = new MetroFramework.Controls.MetroComboBox();
            this.btnExport = new MetroFramework.Controls.MetroButton();
            this.lblBusy = new MetroFramework.Controls.MetroLabel();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.SaveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.cntxMenu = new MetroFramework.Controls.MetroContextMenu(this.components);
            this.editRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cmbStatus = new MetroFramework.Controls.MetroComboBox();
            this.lblErrStatus = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGridGL)).BeginInit();
            this.cntxMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblErrGLName
            // 
            this.lblErrGLName.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblErrGLName.ForeColor = System.Drawing.Color.Red;
            this.lblErrGLName.Location = new System.Drawing.Point(312, 188);
            this.lblErrGLName.Name = "lblErrGLName";
            this.lblErrGLName.Size = new System.Drawing.Size(278, 19);
            this.lblErrGLName.Style = MetroFramework.MetroColorStyle.Red;
            this.lblErrGLName.TabIndex = 27;
            this.lblErrGLName.UseStyleColors = true;
            // 
            // lblErrGLCode
            // 
            this.lblErrGLCode.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblErrGLCode.ForeColor = System.Drawing.Color.Red;
            this.lblErrGLCode.Location = new System.Drawing.Point(312, 139);
            this.lblErrGLCode.Name = "lblErrGLCode";
            this.lblErrGLCode.Size = new System.Drawing.Size(278, 19);
            this.lblErrGLCode.Style = MetroFramework.MetroColorStyle.Red;
            this.lblErrGLCode.TabIndex = 26;
            this.lblErrGLCode.UseStyleColors = true;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(31, 162);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(64, 19);
            this.metroLabel3.TabIndex = 24;
            this.metroLabel3.Text = "GL Name";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(31, 113);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(60, 19);
            this.metroLabel2.TabIndex = 23;
            this.metroLabel2.Text = "GL Code";
            // 
            // txtGLCode
            // 
            this.txtGLCode.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.txtGLCode.CustomButton.Image = null;
            this.txtGLCode.CustomButton.Location = new System.Drawing.Point(256, 1);
            this.txtGLCode.CustomButton.Name = "";
            this.txtGLCode.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtGLCode.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtGLCode.CustomButton.TabIndex = 1;
            this.txtGLCode.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtGLCode.CustomButton.UseSelectable = true;
            this.txtGLCode.CustomButton.Visible = false;
            this.txtGLCode.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txtGLCode.Lines = new string[0];
            this.txtGLCode.Location = new System.Drawing.Point(31, 135);
            this.txtGLCode.MaxLength = 32767;
            this.txtGLCode.Name = "txtGLCode";
            this.txtGLCode.PasswordChar = '\0';
            this.txtGLCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtGLCode.SelectedText = "";
            this.txtGLCode.SelectionLength = 0;
            this.txtGLCode.SelectionStart = 0;
            this.txtGLCode.Size = new System.Drawing.Size(278, 23);
            this.txtGLCode.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtGLCode.TabIndex = 6;
            this.txtGLCode.UseSelectable = true;
            this.txtGLCode.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtGLCode.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // btnSubmit
            // 
            this.btnSubmit.AutoSize = true;
            this.btnSubmit.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnSubmit.ForeColor = System.Drawing.Color.White;
            this.btnSubmit.Highlight = true;
            this.btnSubmit.Location = new System.Drawing.Point(30, 349);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(105, 23);
            this.btnSubmit.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnSubmit.TabIndex = 3;
            this.btnSubmit.Text = "&Add New Record";
            this.btnSubmit.UseCustomBackColor = true;
            this.btnSubmit.UseCustomForeColor = true;
            this.btnSubmit.UseSelectable = true;
            this.btnSubmit.UseStyleColors = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // txtGLName
            // 
            this.txtGLName.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.txtGLName.CustomButton.Image = null;
            this.txtGLName.CustomButton.Location = new System.Drawing.Point(256, 1);
            this.txtGLName.CustomButton.Name = "";
            this.txtGLName.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtGLName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtGLName.CustomButton.TabIndex = 1;
            this.txtGLName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtGLName.CustomButton.UseSelectable = true;
            this.txtGLName.CustomButton.Visible = false;
            this.txtGLName.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txtGLName.Lines = new string[0];
            this.txtGLName.Location = new System.Drawing.Point(31, 184);
            this.txtGLName.MaxLength = 32767;
            this.txtGLName.Name = "txtGLName";
            this.txtGLName.PasswordChar = '\0';
            this.txtGLName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtGLName.SelectedText = "";
            this.txtGLName.SelectionLength = 0;
            this.txtGLName.SelectionStart = 0;
            this.txtGLName.Size = new System.Drawing.Size(278, 23);
            this.txtGLName.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtGLName.TabIndex = 7;
            this.txtGLName.UseSelectable = true;
            this.txtGLName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtGLName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroPanel1
            // 
            this.metroPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.metroPanel1.Controls.Add(this.metroGridGL);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(31, 374);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(646, 248);
            this.metroPanel1.TabIndex = 30;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // metroGridGL
            // 
            this.metroGridGL.AllowUserToAddRows = false;
            this.metroGridGL.AllowUserToDeleteRows = false;
            this.metroGridGL.AllowUserToResizeRows = false;
            this.metroGridGL.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.metroGridGL.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGridGL.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGridGL.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGridGL.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGridGL.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.metroGridGL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.metroGridGL.ContextMenuStrip = this.cntxMenu;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGridGL.DefaultCellStyle = dataGridViewCellStyle5;
            this.metroGridGL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroGridGL.EnableHeadersVisualStyles = false;
            this.metroGridGL.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGridGL.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGridGL.Location = new System.Drawing.Point(0, 0);
            this.metroGridGL.Name = "metroGridGL";
            this.metroGridGL.ReadOnly = true;
            this.metroGridGL.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGridGL.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.metroGridGL.RowHeadersVisible = false;
            this.metroGridGL.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGridGL.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGridGL.Size = new System.Drawing.Size(644, 246);
            this.metroGridGL.TabIndex = 10;
            this.metroGridGL.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroGridGL.UseCustomBackColor = true;
            this.metroGridGL.UseCustomForeColor = true;
            this.metroGridGL.UseStyleColors = true;
            // 
            // btnSearch
            // 
            this.btnSearch.BackgroundImage = global::NTC_Consolidator.Properties.Resources.sync;
            this.btnSearch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSearch.Location = new System.Drawing.Point(645, 343);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(32, 29);
            this.btnSearch.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnSearch.TabIndex = 2;
            this.btnSearch.UseCustomBackColor = true;
            this.btnSearch.UseCustomForeColor = true;
            this.btnSearch.UseSelectable = true;
            this.btnSearch.UseStyleColors = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtSearch
            // 
            // 
            // 
            // 
            this.txtSearch.CustomButton.AutoEllipsis = true;
            this.txtSearch.CustomButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.txtSearch.CustomButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txtSearch.CustomButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.CustomButton.Image = null;
            this.txtSearch.CustomButton.Location = new System.Drawing.Point(212, 1);
            this.txtSearch.CustomButton.Name = "";
            this.txtSearch.CustomButton.Size = new System.Drawing.Size(27, 27);
            this.txtSearch.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtSearch.CustomButton.TabIndex = 1;
            this.txtSearch.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtSearch.CustomButton.UseSelectable = true;
            this.txtSearch.CustomButton.Visible = false;
            this.txtSearch.DisplayIcon = true;
            this.txtSearch.Lines = new string[0];
            this.txtSearch.Location = new System.Drawing.Point(406, 343);
            this.txtSearch.MaxLength = 32767;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.PasswordChar = '\0';
            this.txtSearch.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSearch.SelectedText = "";
            this.txtSearch.SelectionLength = 0;
            this.txtSearch.SelectionStart = 0;
            this.txtSearch.Size = new System.Drawing.Size(240, 29);
            this.txtSearch.TabIndex = 1;
            this.txtSearch.UseSelectable = true;
            this.txtSearch.WaterMark = "Enter Keyword";
            this.txtSearch.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtSearch.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // txtProductDesc
            // 
            this.txtProductDesc.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.txtProductDesc.CustomButton.Image = null;
            this.txtProductDesc.CustomButton.Location = new System.Drawing.Point(256, 1);
            this.txtProductDesc.CustomButton.Name = "";
            this.txtProductDesc.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtProductDesc.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtProductDesc.CustomButton.TabIndex = 1;
            this.txtProductDesc.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtProductDesc.CustomButton.UseSelectable = true;
            this.txtProductDesc.CustomButton.Visible = false;
            this.txtProductDesc.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txtProductDesc.Lines = new string[0];
            this.txtProductDesc.Location = new System.Drawing.Point(31, 232);
            this.txtProductDesc.MaxLength = 32767;
            this.txtProductDesc.Name = "txtProductDesc";
            this.txtProductDesc.PasswordChar = '\0';
            this.txtProductDesc.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtProductDesc.SelectedText = "";
            this.txtProductDesc.SelectionLength = 0;
            this.txtProductDesc.SelectionStart = 0;
            this.txtProductDesc.Size = new System.Drawing.Size(278, 23);
            this.txtProductDesc.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtProductDesc.TabIndex = 8;
            this.txtProductDesc.UseSelectable = true;
            this.txtProductDesc.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtProductDesc.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // lblErrProductDesc
            // 
            this.lblErrProductDesc.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblErrProductDesc.ForeColor = System.Drawing.Color.Red;
            this.lblErrProductDesc.Location = new System.Drawing.Point(312, 236);
            this.lblErrProductDesc.Name = "lblErrProductDesc";
            this.lblErrProductDesc.Size = new System.Drawing.Size(278, 19);
            this.lblErrProductDesc.Style = MetroFramework.MetroColorStyle.Red;
            this.lblErrProductDesc.TabIndex = 33;
            this.lblErrProductDesc.UseStyleColors = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(31, 210);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(124, 19);
            this.metroLabel4.TabIndex = 32;
            this.metroLabel4.Text = "Product Description";
            // 
            // lblErrSystemTagging
            // 
            this.lblErrSystemTagging.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblErrSystemTagging.ForeColor = System.Drawing.Color.Red;
            this.lblErrSystemTagging.Location = new System.Drawing.Point(312, 93);
            this.lblErrSystemTagging.Name = "lblErrSystemTagging";
            this.lblErrSystemTagging.Size = new System.Drawing.Size(278, 19);
            this.lblErrSystemTagging.Style = MetroFramework.MetroColorStyle.Red;
            this.lblErrSystemTagging.TabIndex = 36;
            this.lblErrSystemTagging.UseStyleColors = true;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(31, 60);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(50, 19);
            this.metroLabel5.TabIndex = 35;
            this.metroLabel5.Text = "System";
            // 
            // cmbSysTagging
            // 
            this.cmbSysTagging.BackColor = System.Drawing.Color.White;
            this.cmbSysTagging.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSysTagging.FormattingEnabled = true;
            this.cmbSysTagging.ItemHeight = 23;
            this.cmbSysTagging.Items.AddRange(new object[] {
            "ICBS",
            "AAF",
            "FAMS"});
            this.cmbSysTagging.Location = new System.Drawing.Point(32, 83);
            this.cmbSysTagging.Name = "cmbSysTagging";
            this.cmbSysTagging.Size = new System.Drawing.Size(274, 29);
            this.cmbSysTagging.TabIndex = 5;
            this.cmbSysTagging.UseSelectable = true;
            // 
            // btnExport
            // 
            this.btnExport.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnExport.ForeColor = System.Drawing.Color.White;
            this.btnExport.Highlight = true;
            this.btnExport.Location = new System.Drawing.Point(582, 638);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(95, 23);
            this.btnExport.TabIndex = 4;
            this.btnExport.Text = "Export To Excel";
            this.btnExport.UseCustomBackColor = true;
            this.btnExport.UseCustomForeColor = true;
            this.btnExport.UseSelectable = true;
            this.btnExport.UseStyleColors = true;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // lblBusy
            // 
            this.lblBusy.ForeColor = System.Drawing.Color.Red;
            this.lblBusy.Location = new System.Drawing.Point(306, 640);
            this.lblBusy.Name = "lblBusy";
            this.lblBusy.Size = new System.Drawing.Size(270, 21);
            this.lblBusy.TabIndex = 39;
            this.lblBusy.Text = "[busy status]";
            this.lblBusy.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblBusy.UseCustomForeColor = true;
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            this.backgroundWorker1.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker1_RunWorkerCompleted);
            // 
            // cntxMenu
            // 
            this.cntxMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editRecordToolStripMenuItem,
            this.deleteRecordToolStripMenuItem});
            this.cntxMenu.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.cntxMenu.Name = "cntxMenu";
            this.cntxMenu.Size = new System.Drawing.Size(143, 48);
            // 
            // editRecordToolStripMenuItem
            // 
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new System.EventHandler(this.editRecordToolStripMenuItem_Click);
            // 
            // deleteRecordToolStripMenuItem
            // 
            this.deleteRecordToolStripMenuItem.Name = "deleteRecordToolStripMenuItem";
            this.deleteRecordToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.deleteRecordToolStripMenuItem.Text = "Delete Record";
            this.deleteRecordToolStripMenuItem.Click += new System.EventHandler(this.deleteRecordToolStripMenuItem_Click);
            // 
            // cmbStatus
            // 
            this.cmbStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.IntegralHeight = false;
            this.cmbStatus.ItemHeight = 23;
            this.cmbStatus.Items.AddRange(new object[] {
            "Current",
            "Pending",
            "Complete",
            "Rejected"});
            this.cmbStatus.Location = new System.Drawing.Point(31, 281);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(274, 29);
            this.cmbStatus.TabIndex = 9;
            this.cmbStatus.UseSelectable = true;
            // 
            // lblErrStatus
            // 
            this.lblErrStatus.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblErrStatus.ForeColor = System.Drawing.Color.Red;
            this.lblErrStatus.Location = new System.Drawing.Point(311, 291);
            this.lblErrStatus.Name = "lblErrStatus";
            this.lblErrStatus.Size = new System.Drawing.Size(278, 19);
            this.lblErrStatus.Style = MetroFramework.MetroColorStyle.Red;
            this.lblErrStatus.TabIndex = 42;
            this.lblErrStatus.UseStyleColors = true;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(30, 258);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(43, 19);
            this.metroLabel6.TabIndex = 41;
            this.metroLabel6.Text = "Status";
            // 
            // frmCorrespondingGL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(706, 676);
            this.Controls.Add(this.cmbStatus);
            this.Controls.Add(this.lblErrStatus);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.lblBusy);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.cmbSysTagging);
            this.Controls.Add(this.lblErrSystemTagging);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.txtProductDesc);
            this.Controls.Add(this.lblErrProductDesc);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.txtGLName);
            this.Controls.Add(this.lblErrGLName);
            this.Controls.Add(this.lblErrGLCode);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.txtGLCode);
            this.Controls.Add(this.btnSubmit);
            this.MaximizeBox = false;
            this.Name = "frmCorrespondingGL";
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.DropShadow;
            this.Style = MetroFramework.MetroColorStyle.Yellow;
            this.Text = "Corresponding GL";
            this.Load += new System.EventHandler(this.frmCorrespomdingGL_Load);
            this.metroPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.metroGridGL)).EndInit();
            this.cntxMenu.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel lblErrGLName;
        private MetroFramework.Controls.MetroLabel lblErrGLCode;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroTextBox txtGLCode;
        private MetroFramework.Controls.MetroButton btnSubmit;
        private MetroFramework.Controls.MetroTextBox txtGLName;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroGrid metroGridGL;
        private MetroFramework.Controls.MetroButton btnSearch;
        private MetroFramework.Controls.MetroTextBox txtSearch;
        private MetroFramework.Controls.MetroTextBox txtProductDesc;
        private MetroFramework.Controls.MetroLabel lblErrProductDesc;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel lblErrSystemTagging;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroComboBox cmbSysTagging;
        private MetroFramework.Controls.MetroButton btnExport;
        private MetroFramework.Controls.MetroLabel lblBusy;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.SaveFileDialog SaveFileDialog;
        private MetroFramework.Controls.MetroContextMenu cntxMenu;
        private System.Windows.Forms.ToolStripMenuItem editRecordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteRecordToolStripMenuItem;
        private MetroFramework.Controls.MetroComboBox cmbStatus;
        private MetroFramework.Controls.MetroLabel lblErrStatus;
        private MetroFramework.Controls.MetroLabel metroLabel6;
    }
}