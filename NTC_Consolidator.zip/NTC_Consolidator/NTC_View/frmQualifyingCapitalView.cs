﻿using MetroFramework.Forms;
using NTC_Consolidator.Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmQualifyingCapitalView : MetroForm
    {
        SaveFileDialog diag = new SaveFileDialog();
        DataTable dt = new DataTable();
        string filename = "";

        private static frmQualifyingCapitalView glform = null;

        public static frmQualifyingCapitalView Instance()
        {
            if (glform == null)
            {
                glform = new frmQualifyingCapitalView();
            }
            return glform;
        }

        public frmQualifyingCapitalView()
        {
            InitializeComponent();
        }

        private void frmQualifyingCapitalView_Load(object sender, EventArgs e)
        {
            //var _instance = new NTCService();

            //dt = _instance.GetAllQualifyingCapitalRecord();

            Search(txtSearch.Text);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            Search("");
        }

        private void Search(string keyword)
        {
            if (!string.IsNullOrEmpty(keyword))
            {
                DataView dv = new DataView(dt);
                dv.RowFilter = "Description LIKE '%" + keyword + "%'";

                metroGridGL.DataSource = dv;
            }
            else
            {
                metroGridGL.DataSource = dt;
            }
            this.metroGridGL.Columns["Description"].Width = 180;
        }
       
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            Search(txtSearch.Text);
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            
            // Check if the backgroundWorker is already busy running the asynchronous operation
            if (!backgroundWorker1.IsBusy /*&& fileValidatedAndNoErrors*/)
            {
                ExportToExcel();
            }
            else
            {
                lblBusy.Text = "Busy processing, Please wait...";
            }
        }

        private void ExportToExcel()
        {
            // Stream myStream;
            diag.Filter = "Excel|*.xls|Excel 2010|*.xlsx";
            diag.Title = "Save Qualifying Capital";
            diag.ShowDialog();
            filename = Path.GetFileName(diag.FileName);

            if (diag.FileName != "")
            {
                // This method will start the execution asynchronously in the background
                backgroundWorker1.RunWorkerAsync();
            }
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            //open file
            StreamWriter wr = new StreamWriter(diag.FileName, false, Encoding.Unicode);

            try
            {
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    wr.Write(dt.Columns[i].ToString().ToUpper() + "\t");
                }

                wr.WriteLine();

                //write rows to excel file
                for (int i = 0; i < (dt.Rows.Count); i++)
                {
                    Thread.Sleep(1000);
                    for (int j = 0; j < dt.Columns.Count; j++)
                    {
                        if (dt.Rows[i][j] != null)
                        {
                            wr.Write("" + Convert.ToString(dt.Rows[i][j]) + "" + "\t");
                        }
                        else
                        {
                            wr.Write("\t");
                        }
                    }
                    //go to next line
                    wr.WriteLine();
                }
                //close file
                wr.Close();
            }
            catch (Exception ex)
            {
                lblBusy.Text = "";
                MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nError encountered while generating the excel file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            lblBusy.Text = "";
            MetroFramework.MetroMessageBox.Show(this, "\r\n\r\n" + filename + " file was successfully generated", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
