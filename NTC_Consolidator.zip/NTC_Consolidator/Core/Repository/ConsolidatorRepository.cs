﻿using NTC_Consolidator.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NTC_Consolidator.Data;
using System.Data.Entity;
using System.Data;
using System.Collections;
using System.Data.SqlClient;

namespace NTC_Consolidator.Core.Repository
{
    public class ConsolidatorRepository : IConsolidator, IDisposable
    {
        private NTC_Context_Entities context;
        DbSet<BDOLF_NTC_Consolidator> _bjectSet;

        public ConsolidatorRepository(NTC_Context_Entities context)
        {
            this.context = context;
            _bjectSet = context.Set<BDOLF_NTC_Consolidator>();
        }

        public void BulkDelete(object[] objdata)
        {
            throw new NotImplementedException();
        }

        public void BulkInsert(object[] objdata)
        {
            var icbsData = (DataTable)objdata[0];
            var aafData = (DataTable)objdata[1];
            var famsData = (ArrayList)objdata[2];
            var sdf = new BDOLF_NTC_Consolidator();

            string connectionString = (new NTC_Context_Entities()).Database.Connection.ConnectionString;
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.TableLock, transaction))
                        {
                            context.Configuration.AutoDetectChangesEnabled = false;
                            context.Configuration.ValidateOnSaveEnabled = false;

                            // my DataTable column names match my SQL Column names, so I simply made this loop. However if your column names don't match, just pass in which datatable name matches the SQL column name in Column Mappings
                            foreach (DataColumn col in icbsData.Columns)
                            {
                                sqlBulkCopy.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                            }

                            sqlBulkCopy.BulkCopyTimeout = 0;
                            //sqlBulkCopy.DestinationTableName = "BDOLF_NTC_Consolidator";
                            //sqlBulkCopy.WriteToServer(icbsData);


                            #region MyRegion

                            sqlBulkCopy.DestinationTableName = "BDOLF_NTC_Consolidator";

                            //sqlBulkCopy.ColumnMappings.Add("TransID", "TransID");
                            sqlBulkCopy.ColumnMappings.Add("TranNo", "TranNo");
                            sqlBulkCopy.ColumnMappings.Add("RawFiles", "RawFiles");
                            sqlBulkCopy.ColumnMappings.Add("isConsolidated", "isConsolidated");
                            sqlBulkCopy.ColumnMappings.Add("isDeleted", "isDeleted");
                            sqlBulkCopy.ColumnMappings.Add("UserName", "UserName");
                            sqlBulkCopy.ColumnMappings.Add("TransDate", "TransDate");
                            sqlBulkCopy.ColumnMappings.Add("RecordDate", "RecordDate");
                            sqlBulkCopy.ColumnMappings.Add("SYSTEM", "SYSTEM");
                            sqlBulkCopy.ColumnMappings.Add("AccountNo", "AccountNo");
                            sqlBulkCopy.ColumnMappings.Add("ClientName", "ClientName");
                            sqlBulkCopy.ColumnMappings.Add("AO", "AO");
                            sqlBulkCopy.ColumnMappings.Add("FacilityCode", "FacilityCode");
                            sqlBulkCopy.ColumnMappings.Add("StatusPerSystem", "StatusPerSystem");
                            sqlBulkCopy.ColumnMappings.Add("ValueDate", "ValueDate");
                            //sqlBulkCopy.ColumnMappings.Add("FirstDueDate", "FirstDueDate");
                            sqlBulkCopy.ColumnMappings.Add("MaturityDate", "MaturityDate");
                            sqlBulkCopy.ColumnMappings.Add("TotalLoan", "TotalLoan");
                            sqlBulkCopy.ColumnMappings.Add("OB", "OB");
                            sqlBulkCopy.ColumnMappings.Add("MonthlyOB", "MonthlyOB");
                            //sqlBulkCopy.ColumnMappings.Add("UDIBalance", "UDIBalance");
                           // sqlBulkCopy.ColumnMappings.Add("ClientsEquity", "ClientsEquity");
                            sqlBulkCopy.ColumnMappings.Add("AccruedInterestReceivable", "AccruedInterestReceivable");
                            //sqlBulkCopy.ColumnMappings.Add("OrigERV", "OrigERV");
                           // sqlBulkCopy.ColumnMappings.Add("PVRV", "PVRV");
                            //sqlBulkCopy.ColumnMappings.Add("OrigGD", "OrigGD");
                            //sqlBulkCopy.ColumnMappings.Add("PVGD", "PVGD");
                           // sqlBulkCopy.ColumnMappings.Add("TotalLoanPortfolio", "TotalLoanPortfolio");
                            //sqlBulkCopy.ColumnMappings.Add("NTC", "NTC");
                            sqlBulkCopy.ColumnMappings.Add("OriginalRate", "OriginalRate");
                            sqlBulkCopy.ColumnMappings.Add("CurrentRate", "CurrentRate");
                            sqlBulkCopy.ColumnMappings.Add("TermInMonths", "TermInMonths");
                            //sqlBulkCopy.ColumnMappings.Add("RemainingTermInMonths", "RemainingTermInMonths");
                            //sqlBulkCopy.ColumnMappings.Add("OriginalAmortizationAAF", "OriginalAmortizationAAF");
                           // sqlBulkCopy.ColumnMappings.Add("PaymentScheduleAmortizationAAF", "PaymentScheduleAmortizationAAF");
                           // sqlBulkCopy.ColumnMappings.Add("RepricedDate", "RepricedDate");
                            sqlBulkCopy.ColumnMappings.Add("AAFICBSRateType", "AAFICBSRateType");
                           // sqlBulkCopy.ColumnMappings.Add("RepricedAmortization", "RepricedAmortization");
                            sqlBulkCopy.ColumnMappings.Add("PastDueDateITLDateExtractedPerAAFICBS", "PastDueDateITLDateExtractedPerAAFICBS");
                            sqlBulkCopy.ColumnMappings.Add("PerFaMSAAFICBSIndustryCode", "PerFaMSAAFICBSIndustryCode");
                            sqlBulkCopy.ColumnMappings.Add("IndustryHeader", "IndustryHeader");
                            sqlBulkCopy.ColumnMappings.Add("IndustryDetail", "IndustryDetail");
                            //sqlBulkCopy.ColumnMappings.Add("Collateral", "Collateral");
                            sqlBulkCopy.ColumnMappings.Add("PerFaMSAAFICBSAssetSize", "PerFaMSAAFICBSAssetSize");
                            //sqlBulkCopy.ColumnMappings.Add("PerFaMSAAFICBSAssetSizeInWords", "PerFaMSAAFICBSAssetSizeInWords");
                            //sqlBulkCopy.ColumnMappings.Add("ICBSGLCode", "ICBSGLCode");
                            //sqlBulkCopy.ColumnMappings.Add("ICBSGLName", "ICBSGLName");
                            sqlBulkCopy.ColumnMappings.Add("CostCenter", "CostCenter");
                           // sqlBulkCopy.ColumnMappings.Add("BranchNameOfCostCenterPerSystem", "BranchNameOfCostCenterPerSystem");
                            //sqlBulkCopy.ColumnMappings.Add("StatusPerGL", "StatusPerGL");
                            //sqlBulkCopy.ColumnMappings.Add("OriginatingBranchBooked", "OriginatingBranchBooked");
                            sqlBulkCopy.ColumnMappings.Add("NationalityPerICBS", "NationalityPerICBS");
                            sqlBulkCopy.ColumnMappings.Add("NextRateReviewDateExtractedPerFaMSAAFICBS", "NextRateReviewDateExtractedPerFaMSAAFICBS");
                            sqlBulkCopy.ColumnMappings.Add("TaxID", "TaxID");
                            sqlBulkCopy.ColumnMappings.Add("LoanPurposeCode", "LoanPurposeCode");
                            sqlBulkCopy.ColumnMappings.Add("MaturityTypeCode", "MaturityTypeCode");
                            sqlBulkCopy.ColumnMappings.Add("BankRelationship", "BankRelationship");
                            sqlBulkCopy.ColumnMappings.Add("SyndicatedLoanInd", "SyndicatedLoanInd");
                            //sqlBulkCopy.ColumnMappings.Add("CustomerTypeDescription", "CustomerTypeDescription");
                            //sqlBulkCopy.ColumnMappings.Add("RELCode", "RELCode");
                            //sqlBulkCopy.ColumnMappings.Add("REECode", "REECode");
                            //sqlBulkCopy.ColumnMappings.Add("REEAddtlInfo", "REEAddtlInfo");
                           // sqlBulkCopy.ColumnMappings.Add("AcctRef", "AcctRef");
                            sqlBulkCopy.ColumnMappings.Add("RPT", "RPT");
                            //sqlBulkCopy.ColumnMappings.Add("ASSETCOST", "ASSETCOST");
                            //sqlBulkCopy.ColumnMappings.Add("LeaseType", "LeaseType");
                            //sqlBulkCopy.ColumnMappings.Add("Provisioning", "Provisioning");
                           // sqlBulkCopy.ColumnMappings.Add("Matrix", "Matrix");
                           // sqlBulkCopy.ColumnMappings.Add("Remarks", "Remarks");
                            sqlBulkCopy.ColumnMappings.Add("ICBSCollateralCode", "ICBSCollateralCode");
                            sqlBulkCopy.ColumnMappings.Add("AssetValue", "AssetValue");
                            sqlBulkCopy.ColumnMappings.Add("ApprovedAmount", "ApprovedAmount");
                           // sqlBulkCopy.ColumnMappings.Add("CPNumber", "CPNumber");
                            sqlBulkCopy.ColumnMappings.Add("LastPrincipalPay", "LastPrincipalPay");
                            sqlBulkCopy.ColumnMappings.Add("PrincipalPayDate", "PrincipalPayDate");
                            sqlBulkCopy.ColumnMappings.Add("LastInterestPay", "LastInterestPay");
                            sqlBulkCopy.ColumnMappings.Add("LastInterestPayDate", "LastInterestPayDate");
                            //sqlBulkCopy.ColumnMappings.Add("PreviousMonthsNPLTaggingByRisk", "PreviousMonthsNPLTaggingByRisk");
                            //sqlBulkCopy.ColumnMappings.Add("SpecificRequiredProvisions", "SpecificRequiredProvisions");
                            //sqlBulkCopy.ColumnMappings.Add("GeneralRequiredProvisions", "GeneralRequiredProvisions");
                            //sqlBulkCopy.ColumnMappings.Add("Reason", "Reason");
                            #endregion

                            //foreach (DataColumn column in aafData.Columns)
                            //{
                            //    sqlBulkCopy.ColumnMappings.Add(column.ColumnName, column.ColumnName);
                            //}

                            sqlBulkCopy.WriteToServer(icbsData);
                           // sqlBulkCopy.WriteToServer(aafData);
                        }
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                    finally
                    {
                        transaction.Dispose();
                        connection.Close();
                    }
                }
            }
        }

        public void BulkUpdete(object[] objdata)
        {
            throw new NotImplementedException();
        }

        public void DeleteFilePathMaintenace(string TransID)
        {
            throw new NotImplementedException();
        }

        public void DeleteFilePathMaintenace(int PathID)
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<BDOLF_NTC_Consolidator> GetAll()
        {
            throw new NotImplementedException();
        }

        public BDOLF_NTC_Consolidator GetByCode(string PathID)
        {
            throw new NotImplementedException();
        }

        public BDOLF_NTC_Consolidator GetByID(int PathID)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<BDOLF_NTC_Consolidator> GetTopOne()
        {
            var query = from data in context.BDOLF_NTC_Consolidator.OrderByDescending(t => t.TransDate).Take(1)
                        select data;

            return query;
        }

        public void InsertFilePathMaintenace(BDOLF_NTC_Consolidator gl)
        {
            throw new NotImplementedException();
        }

        public void Save()
        {
            throw new NotImplementedException();
        }

        public void TruncateTable()
        {
            throw new NotImplementedException();
        }

        public void UpdateFilePathMaintenace(BDOLF_PathMaintenance gl)
        {
            throw new NotImplementedException();
        }
    }
}
